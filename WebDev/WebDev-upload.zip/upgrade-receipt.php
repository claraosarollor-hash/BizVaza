<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

$proPlan = getProPlan($pdo);
$proPrice = $proPlan ? (float)$proPlan['price'] : 1999.00;
$proPriceText = $proPrice > 0 ? '₦' . number_format($proPrice) : 'Free';

$flash = '';
$flashType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['proof'])) {
    validate_csrf();
    $user_id = $_SESSION['user_id'];

    // Validate file
    $file = $_FILES['proof'];
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $flash = 'Please select a file to upload.';
        $flashType = 'error';
    } elseif (!in_array($file['type'], $allowed)) {
        $flash = 'Only JPG, PNG, GIF, WebP, or PDF files are allowed.';
        $flashType = 'error';
    } elseif ($file['size'] > 5 * 1024 * 1024) {
        $flash = 'File must be under 5MB.';
        $flashType = 'error';
    } else {
        // Create uploads directory if needed
        $uploadDir = __DIR__ . '/uploads/upgrade-proofs';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        // Generate filename
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'proof_' . $user_id . '_' . time() . '.' . $ext;
        $filepath = $uploadDir . '/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $reference = 'BF-BANK-' . $user_id . '-' . time();
            $stmt = $pdo->prepare("INSERT INTO subscription_payments (user_id, reference, amount, method, status, proof_path) VALUES (?, ?, ?, 'bank_transfer', 'pending', ?)");
            $stmt->execute([$user_id, $reference, $proPrice, 'upgrade-proofs/' . $filename]);

            logActivity($pdo, $user_id, 'upgrade_request_submitted', 'Submitted bank transfer proof for Pro upgrade', 'subscription', null);

            $flash = 'Payment proof submitted! We will review and activate your Pro plan within 24 hours.';
            $flashType = 'success';
        } else {
            $flash = 'Failed to upload file. Please try again.';
            $flashType = 'error';
        }
    }
}

// Check if user already has pending request
$stmt = $pdo->prepare("SELECT * FROM subscription_payments WHERE user_id = ? AND method = 'bank_transfer' AND status = 'pending' ORDER BY created_at DESC LIMIT 1");
$stmt->execute([$_SESSION['user_id']]);
$pendingRequest = $stmt->fetch();
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>BizFlow — Upload Payment Proof</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="assets/css/styles.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;background:#f8fafc;min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:40px 24px}
.back-link{display:inline-flex;align-items:center;gap:6px;color:#64748b;text-decoration:none;font-size:13px;font-weight:500;margin-bottom:32px}
.back-link:hover{color:#0f172a}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:32px;max-width:520px;width:100%}
.card h1{font-size:20px;font-weight:700;color:#0f172a;margin-bottom:4px}
.card .subtitle{font-size:13px;color:#64748b;margin-bottom:24px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#333;margin-bottom:6px}
.form-group input[type=file]{width:100%;padding:12px;border:2px dashed #d0d6df;border-radius:8px;font-size:13px;font-family:'Inter',sans-serif;background:#fafbfc;cursor:pointer}
.form-group input[type=file]:hover{border-color:#b45309;background:#fff7ed}
.form-group .hint{font-size:11px;color:#94a3b8;margin-top:4px}
.btn{display:inline-flex;align-items:center;padding:12px 24px;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;border:none;font-family:'Inter',sans-serif;width:100%;justify-content:center}
.btn-primary{background:#b45309;color:#fff}
.btn-primary:hover{background:#92400e}
.btn:disabled{opacity:.5;cursor:not-allowed}
.flash{padding:12px 16px;border-radius:8px;font-size:13px;margin-bottom:20px}
.flash.success{background:#d1fae5;border:1px solid #a7f3d0;color:#059669}
.flash.error{background:#fef2f2;border:1px solid #fecaca;color:#dc2626}
.pending-box{background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;padding:14px;margin-top:16px}
.pending-box h4{font-size:13px;font-weight:600;color:#b45309;margin-bottom:4px}
.pending-box p{font-size:12px;color:#92400e}
.bank-details{background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;padding:16px;margin:16px 0}
.bank-details h3{font-size:14px;font-weight:700;color:#1a2332;margin-bottom:10px}
.bank-row{display:grid;grid-template-columns:auto 1fr;gap:6px 14px;font-size:13px;margin-bottom:4px}
.bank-row .lbl{font-weight:600;color:#1a2332}
.bank-row .val{color:#334155}
.bank-row .val.big{font-weight:700;font-size:15px;color:#0f172a}
</style>
</head>
<body>

<a href="pricing.php" class="back-link">
<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
Back to Pricing
</a>

<div class="card">
<h1>Upload Payment Proof</h1>
<p class="subtitle">Submit your bank transfer receipt for verification.</p>

<?php if ($flash): ?>
<div class="flash <?= $flashType ?>"><?= htmlspecialchars($flash) ?></div>
<?php endif; ?>

<?php
$bankName = '';
$acctName = '';
$acctNum = '';
$stmt = $pdo->query("SELECT `key`, `value` FROM settings WHERE `key` LIKE 'payment_%'");
while ($r = $stmt->fetch()) {
    if ($r['key'] === 'payment_bank_name') $bankName = $r['value'];
    if ($r['key'] === 'payment_account_name') $acctName = $r['value'];
    if ($r['key'] === 'payment_account_number') $acctNum = $r['value'];
}
?>

<div class="bank-details">
<h3>Pay <?= $proPriceText ?> to:</h3>
<div class="bank-row">
<span class="lbl">Bank:</span><span class="val"><?= htmlspecialchars($bankName) ?></span>
<span class="lbl">Account Name:</span><span class="val"><?= htmlspecialchars($acctName) ?></span>
<span class="lbl">Account Number:</span><span class="val big"><?= htmlspecialchars($acctNum) ?></span>
</div>
<p style="font-size:11px;color:#94a3b8;margin-top:8px">Transfer exactly <?= $proPriceText ?> and upload the receipt/screenshot below.</p>
</div>

<?php if ($pendingRequest): ?>
<div class="pending-box">
<h4><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-3px;margin-right:6px"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> Pending Review</h4>
<p>Your payment proof submitted on <?= date('M j, Y g:i A', strtotime($pendingRequest['created_at'])) ?> is being reviewed. You'll be upgraded within 24 hours.</p>
</div>
<?php else: ?>

<form method="post" enctype="multipart/form-data">
<?= csrf_field() ?>
<div class="form-group">
<label>Payment Receipt / Screenshot</label>
<input type="file" name="proof" accept="image/*,application/pdf" required>
<p class="hint">Upload a screenshot or PDF of your bank transfer confirmation. Max 5MB.</p>
</div>
<button type="submit" class="btn btn-primary">Submit for Review</button>
</form>

<?php endif; ?>
</div>
</body>
</html>
