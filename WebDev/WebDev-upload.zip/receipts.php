<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$business_abbr = $_SESSION['business_abbr'] ?? 'BIZ';
$avatar_initials = $_SESSION['avatar_initials'];
$business_name = $_SESSION['business_name'];

// Auto-generate next receipt number (monotonic, never reused)
$next_receipt = nextDocNumber($pdo, $user_id, 'receipt', $business_abbr);

// Prefill from invoice
$prefill_customer = '';
$prefill_invoice = '';
$prefill_amount = '';
$prefill_items = [];
if (isset($_GET['invoice_id'])) {
    $inv_id = intval($_GET['invoice_id']);
    $stmt = $pdo->prepare("SELECT invoice_number, customer_name, amount FROM invoices WHERE id = ? AND user_id = ?");
    $stmt->execute([$inv_id, $user_id]);
    $inv = $stmt->fetch();
    if ($inv) {
        $totals = invoicePaymentTotals($pdo, $user_id, $inv['invoice_number']);
        if ($totals['amount'] > 0 && $totals['paid_sum'] >= $totals['amount']) {
            $stmt = $pdo->prepare("SELECT id FROM payments WHERE invoice_number = ? AND user_id = ? ORDER BY id DESC LIMIT 1");
            $stmt->execute([$inv['invoice_number'], $user_id]);
            $latest = $stmt->fetch();
            header('Location: view-receipt.php?id=' . ($latest ? $latest['id'] : 0));
            exit;
        }
        $prefill_customer = htmlspecialchars($inv['customer_name'], ENT_QUOTES);
        $prefill_invoice = htmlspecialchars($inv['invoice_number'], ENT_QUOTES);
        $prefill_amount = htmlspecialchars(number_format($totals['remaining'], 2, '.', ''), ENT_QUOTES);
        $stmt = $pdo->prepare("SELECT name, description, quantity, unit_price, amount FROM invoice_items WHERE invoice_id = ?");
        $stmt->execute([$inv_id]);
        $prefill_items = $stmt->fetchAll();
    }
}

$catalog_items = [];
$stmt = $pdo->prepare("SELECT name FROM items WHERE user_id = ? ORDER BY name");
$stmt->execute([$user_id]);
$catalog_items = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Handle Record Receipt form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    validate_csrf();

if ($_POST['action'] === 'record_receipt') {
    $receipt = trim($_POST['receipt_number'] ?? '');
    $customer = trim($_POST['customer_name'] ?? '');
    $invoice = trim($_POST['invoice_number'] ?? '');

    // Parse line items (standalone receipts only)
    $item_names = $_POST['item_name'] ?? [];
    $item_descs = $_POST['item_description'] ?? [];
    $item_types = $_POST['item_type'] ?? [];
    $item_qtys = $_POST['item_qty'] ?? [];
    $item_prices = $_POST['item_price'] ?? [];
    $parsed_items = [];
    $items_total = 0;
    foreach ($item_names as $i => $name) {
        $name = trim($name);
        if ($name === '') continue;
        $type = (trim($item_types[$i] ?? 'product') === 'service') ? 'service' : 'product';
        $qty = max(0, intval($item_qtys[$i] ?? 1));
        if ($type === 'service') { $qty = 1; }
        $price = max(0, floatval(str_replace(',', '', $item_prices[$i] ?? '0')));
        $line_amt = round($qty * $price * 100) / 100;
        $items_total += $line_amt;
        $parsed_items[] = ['name' => $name, 'desc' => trim($item_descs[$i] ?? ''), 'type' => $type, 'qty' => $qty, 'price' => $price, 'amount' => $line_amt];
    }
    $items_total = round($items_total * 100) / 100;

    $amount = ($invoice === '' && count($parsed_items) > 0) ? $items_total : floatval($_POST['amount'] ?? 0);
    $pdate = $_POST['payment_date'] ?? date('Y-m-d');
    $status = $_POST['status'] ?? 'paid';
    $notes = trim($_POST['notes'] ?? '');
    if ($receipt !== '' && $customer !== '') {
        $block_msg = '';
        if ($invoice !== '') {
            $stmt = $pdo->prepare("SELECT id FROM invoices WHERE invoice_number = ? AND user_id = ?");
            $stmt->execute([$invoice, $user_id]);
            if (!$stmt->fetch()) {
                $block_msg = "Invoice number {$invoice} was not found. Leave the invoice field empty to record a standalone receipt.";
            } else {
                $totals = invoicePaymentTotals($pdo, $user_id, $invoice);
                if ($totals['amount'] > 0 && $totals['paid_sum'] >= $totals['amount']) {
                    $block_msg = "Invoice {$invoice} has been fully paid; no more receipts can be generated for it.";
                } elseif ($totals['amount'] > 0 && $totals['paid_sum'] + $amount > $totals['amount']) {
                    $block_msg = "This receipt would exceed the outstanding balance of ₦" . number_format($totals['remaining'], 2) . " on invoice {$invoice}.";
                }
            }
        }
        if ($block_msg === '') {
            $stmt = $pdo->prepare("SELECT id FROM payments WHERE receipt_number = ? AND user_id = ? LIMIT 1");
            $stmt->execute([$receipt, $user_id]);
            if ($stmt->fetch()) {
                $block_msg = "Receipt number {$receipt} is already in use. Use the suggested receipt number.";
            }
        }
        if ($block_msg === '') {
            consumeDocNumber($pdo, $user_id, 'receipt', $business_abbr);
            try {
                $stmt = $pdo->prepare("INSERT INTO payments (user_id, receipt_number, customer_name, invoice_number, amount, payment_date, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $receipt, $customer, $invoice, $amount, $pdate, $status, $notes]);
                $receipt_id = $pdo->lastInsertId();
                if ($invoice === '' && count($parsed_items) > 0) {
                    $ritem = $pdo->prepare("INSERT INTO receipt_items (receipt_id, name, type, description, quantity, unit_price, amount) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    foreach ($parsed_items as $it) {
                        $ritem->execute([$receipt_id, $it['name'], 'product', $it['desc'], $it['qty'], $it['price'], $it['amount']]);
                    }
                }
                logActivity($pdo, $user_id, 'payment_recorded', "Receipt {$receipt} — ₦" . number_format($amount, 2) . " from {$customer}", 'payment', $receipt_id);
                header('Location: view-receipt.php?id=' . $receipt_id);
                exit;
            } catch (PDOException $e) {
                error_log('BizFlow record_receipt failed: ' . $e->getMessage());
                $_SESSION['flash_error'] = 'That receipt number or invoice reference is already in use. Please use a different one.';
            }
        } else {
            $_SESSION['flash_error'] = $block_msg;
        }
    } else {
        $_SESSION['flash_error'] = 'Receipt number and customer name are required.';
    }
    header('Location: receipts.php');
    exit;
}
}

// Fetch receipts
$stmt = $pdo->prepare("SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$receipts = $stmt->fetchAll();

$activePage = 'receipts';
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>BizFlow – Receipts</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css?v=<?= @filemtime(__DIR__ . '/assets/css/styles.css') ?>">
<style>
.content{padding:28px 36px;flex:1}
.receipts-list-section{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:18px 16px}
.receipts-list-section h2{font-size:16px;font-weight:600;color:#0f172a;margin-bottom:14px}
.rcp-table{width:100%;border-collapse:collapse}
.rcp-table thead th{font-size:11px;color:#8da0c0;font-weight:500;text-align:left;padding:8px 10px;background:#fafbfc;border-bottom:1px solid #eef0f4;white-space:nowrap}
.rcp-table tbody td{padding:10px;font-size:12px;color:#3a4559;border-bottom:1px solid #f3f4f6}
.rcp-table tbody tr:last-child td{border-bottom:none}
.rcp-table tbody tr:hover{background:#fafbfd}
.empty-receipts{padding:32px 16px;text-align:center;font-size:13px;color:#94a3b8}
.btn-generate{display:inline-flex;align-items:center;gap:6px;background:#b45309;color:#fff;border:none;border-radius:8px;padding:10px 20px;font-size:14px;font-weight:600;cursor:pointer;margin-top:16px;font-family:'Inter',sans-serif}
.btn-generate:hover{background:#92400e}
.btn-submit{width:100%;background:#b45309;color:#fff;border:none;border-radius:8px;padding:11px 24px;font-size:15px;font-weight:700;font-family:'Inter',sans-serif;cursor:pointer;margin-top:8px}
.btn-submit:hover{background:#92400e}
.form-card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:28px;max-width:700px;width:100%}
.form-card h2{font-size:16px;font-weight:600;color:#0f172a;margin-bottom:18px}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}
@media(max-width:768px){.content{padding:16px}.grid-2{grid-template-columns:1fr}}
</style>
</head>
<body class="dashboard-body">

<?php require __DIR__ . '/includes/sidebar.php'; ?>

<div class="main-content">

<div class="invoice-topbar">
<div class="invoice-topbar-left">
<button class="hamburger-btn" onclick="toggleSidebar()"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg></button>
<div>
<h2>Receipts</h2>
<p>Manage generated receipts</p>
</div>
</div>
<div class="invoice-topbar-right">
<button class="icon-btn" id="bellBtn" onclick="toggleNotif(event)" style="position:relative">
<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8da0c0" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
<span class="bell-dot"></span>
</button>
<?php require __DIR__ . '/includes/user-menu.php'; ?>
</div>
</div>

<div class="content">

<?php if (isset($_SESSION['flash_success'])): ?>
<div class="flash-success"><?= htmlspecialchars($_SESSION['flash_success']) ?><?php unset($_SESSION['flash_success']); ?></div>
<?php endif; ?>
<?php if (isset($_SESSION['flash_error'])): ?>
<div class="flash-error"><?= htmlspecialchars($_SESSION['flash_error']) ?><?php unset($_SESSION['flash_error']); ?></div>
<?php endif; ?>

<div class="receipts-list-section">
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
<h2 style="margin:0">All Receipts</h2>
<button class="btn-generate" onclick="showForm()" style="margin:0">+ Generate Receipt</button>
</div>

<?php if (count($receipts) > 0): ?>
<div class="table-responsive">
<table class="rcp-table">
<thead>
<tr>
<th>Receipt #</th>
<th>Customer</th>
<th>Invoice #</th>
<th>Amount (₦)</th>
<th>Date</th>
<th>Status</th>
</tr>
</thead>
<tbody>
<?php foreach ($receipts as $r): ?>
<tr>
<td><a href="view-receipt.php?id=<?= $r['id'] ?>" style="color:#b45309;font-weight:500;text-decoration:none"><?= htmlspecialchars($r['receipt_number']) ?></a></td>
<td><?= htmlspecialchars($r['customer_name']) ?></td>
<td><?= htmlspecialchars($r['invoice_number']) ?></td>
<td>₦<?= number_format($r['amount'], 2) ?></td>
<td><?= $r['payment_date'] ? date('M d, Y', strtotime($r['payment_date'])) : 'N/A' ?></td>
<td><span class="badge b-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php else: ?>
<div class="empty-receipts">No receipts yet. Generate your first receipt below.</div>
<?php endif; ?>

</div>

<div class="form-wrapper <?= isset($_GET['invoice_id']) && intval($_GET['invoice_id']) > 0 ? 'show' : '' ?>" id="formWrapper">
<div class="form-header">
<h2>Generate Receipt</h2>
<button class="btn-cancel-form" type="button" onclick="hideForm()">Cancel</button>
</div>
<form method="POST">
<?= csrf_field() ?>
<input type="hidden" name="action" value="record_receipt">
<div class="form-card">
<div class="grid-2">
<div class="form-group">
<label>Receipt Number</label>
<input type="text" name="receipt_number" value="<?= htmlspecialchars($next_receipt) ?>" required>
</div>
<div class="form-group">
<label>Payment Date</label>
<input type="date" name="payment_date" value="<?= date('Y-m-d') ?>">
</div>
</div>
<div class="grid-2">
<div class="form-group">
<label>Customer Name *</label>
<input type="text" name="customer_name" value="<?= $prefill_customer ?>" required>
</div>
<div class="form-group">
<label>Invoice Number</label>
<input type="text" name="invoice_number" value="<?= $prefill_invoice ?>">
</div>
</div>
<div class="grid-2">
<div class="form-group">
<label>Amount (₦) *</label>
<input type="number" name="amount" step="0.01" value="<?= $prefill_amount ?: '0' ?>" required>
</div>
<div class="form-group">
<label>Status</label>
<select name="status">
<option value="paid">Paid</option>
<option value="processing">Processing</option>
<option value="failed">Failed</option>
</select>
</div>
</div>
<div id="rcptItemsEditor" style="margin-top:6px">
<label style="font-size:13px;font-weight:600;color:#0f172a;display:block;margin-bottom:8px">Items / Services</label>
<div class="table-responsive">
<div style="min-width:640px">
<div style="display:grid;grid-template-columns:1fr 1fr 56px 110px 110px 32px;gap:8px;margin-bottom:6px">
<span style="font-size:11px;color:#8da0c0;font-weight:500">Item</span>
<span style="font-size:11px;color:#8da0c0;font-weight:500">Description</span>
<span style="font-size:11px;color:#8da0c0;font-weight:500;text-align:center">Qty</span>
<span style="font-size:11px;color:#8da0c0;font-weight:500;text-align:right">Unit Price (₦)</span>
<span style="font-size:11px;color:#8da0c0;font-weight:500;text-align:right">Amount (₦)</span>
<span></span>
</div>
<div id="rcptItemsBody" style="margin-bottom:8px">
<div class="rcp-item-row" style="display:grid;grid-template-columns:1fr 1fr 56px 110px 110px 32px;gap:8px;margin-bottom:6px">
<input type="text" name="item_name[]" placeholder="Item name" list="rcpt-items-list" data-voice style="padding:8px 10px;border:1px solid #e5e7eb;border-radius:6px;font-size:13px;font-family:'Inter',sans-serif;color:#0f172a;outline:none;width:100%;box-sizing:border-box">
<input type="text" name="item_description[]" placeholder="Description" data-voice style="padding:8px 10px;border:1px solid #e5e7eb;border-radius:6px;font-size:13px;font-family:'Inter',sans-serif;color:#0f172a;outline:none;width:100%;box-sizing:border-box">
<input type="number" name="item_qty[]" class="rcp-qty-input" value="1" min="1" style="padding:8px 10px;border:1px solid #e5e7eb;border-radius:6px;font-size:13px;font-family:'Inter',sans-serif;color:#0f172a;outline:none;text-align:center;width:100%;box-sizing:border-box">
<input type="text" name="item_price[]" class="rcp-price-input" placeholder="0.00" inputmode="decimal" data-voice style="padding:8px 10px;border:1px solid #e5e7eb;border-radius:6px;font-size:13px;font-family:'Inter',sans-serif;color:#0f172a;outline:none;text-align:right;width:100%;box-sizing:border-box">
<input type="text" name="item_amount[]" class="rcp-amount-input" value="0.00" readonly style="padding:8px 10px;border:1px solid #eef0f4;border-radius:6px;font-size:13px;font-family:'Inter',sans-serif;color:#8da0c0;outline:none;text-align:right;background:#fafbfc;width:100%;box-sizing:border-box">
<button type="button" class="rcp-del-row" title="Delete Item" style="border:none;background:none;color:#c0c8d4;font-size:18px;cursor:pointer;line-height:1;padding:8px 0">×</button>
</div>
</div>
</div>
</div>
<button type="button" id="rcpAddItem" style="display:inline-flex;align-items:center;gap:6px;background:#fff7ed;color:#b45309;border:1px solid #fed7aa;border-radius:8px;padding:8px 14px;font-size:13px;font-weight:600;cursor:pointer;font-family:'Inter',sans-serif">+ Add Item</button>
<datalist id="rcpt-items-list">
<?php foreach ($catalog_items as $ci): ?>
<option value="<?= htmlspecialchars($ci) ?>">
<?php endforeach; ?>
</datalist>
</div>
<div class="form-group">
<label>Notes (Optional)</label>
<textarea name="notes" rows="3" style="resize:none;width:100%;padding:9px 12px;border:1px solid #e5e7eb;border-radius:8px;font-size:13px;font-family:'Inter',sans-serif;color:#0f172a;outline:none" placeholder="Additional notes..."><?= htmlspecialchars($_SESSION['receipt_default_notes'] ?? '') ?></textarea>
</div>

<?php if (count($prefill_items) > 0): ?>
<div class="table-responsive">
<div style="margin-top:12px;margin-bottom:12px">
<table style="width:100%;border-collapse:collapse;font-size:12px">
<thead>
<tr style="background:#f9fafb;border-bottom:1px solid #e5e7eb">
<th style="padding:6px 8px;text-align:left;color:#64748b;font-weight:500">Item</th>
<th style="padding:6px 8px;text-align:center;color:#64748b;font-weight:500">Qty</th>
<th style="padding:6px 8px;text-align:right;color:#64748b;font-weight:500">Amount (₦)</th>
</tr>
</thead>
<tbody>
<?php foreach ($prefill_items as $pi): ?>
<tr style="border-bottom:1px solid #f1f5f9">
<td style="padding:6px 8px;color:#0f172a"><?= htmlspecialchars($pi['name']) ?></td>
<td style="padding:6px 8px;text-align:center;color:#64748b"><?= intval($pi['quantity']) ?></td>
<td style="padding:6px 8px;text-align:right;color:#0f172a;font-weight:500"><?= number_format(floatval($pi['amount']), 2) ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>
<?php endif; ?>

<button type="submit" class="btn-submit">Generate Receipt</button>
</div>
</form>
</div>

</div>

<script src="assets/js/app.js"></script>
<script src="receipts.js"></script>
<script src="assets/js/speech-input.js"></script>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/notification.php'; ?>
</div>
</body>
</html>
