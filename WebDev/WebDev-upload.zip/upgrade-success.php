<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

$reference = $_GET['reference'] ?? '';
$status = $_GET['status'] ?? '';

if (!$reference || !$status) {
    header('Location: pricing.php');
    exit;
}

// Get Paystack secret key
$stmt = $pdo->prepare("SELECT `value` FROM settings WHERE `key` = ?");
$stmt->execute(['paystack_secret_key']);
$secret = $stmt->fetchColumn();

if (!$secret) {
    header('Location: pricing.php?error=gateway_not_configured');
    exit;
}

// Verify with Paystack API
$url = 'https://api.paystack.co/transaction/verify/' . urlencode($reference);
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $secret,
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => true,
]);
$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
$result = json_decode($response, true);

if ($http_code === 200 && $result['status'] === true && $result['data']['status'] === 'success') {
    $data = $result['data'];
    $verified_amount = $data['amount'] / 100;
    $user_id = $data['metadata']['user_id'] ?? 0;
    $plan_id = $data['metadata']['plan_id'] ?? 2;

    if ($user_id && isset($_SESSION['user_id']) && (int)$_SESSION['user_id'] === (int)$user_id) {
        // Update subscription payment record
        $stmt = $pdo->prepare("UPDATE subscription_payments SET status = 'verified', verified_at = NOW() WHERE reference = ?");
        $stmt->execute([$reference]);

        // Activate Pro plan - 30 days from now
        $expiry = date('Y-m-d H:i:s', strtotime('+30 days'));
        $stmt = $pdo->prepare("UPDATE users SET plan_id = ?, plan_updated_at = NOW(), plan_expires_at = ? WHERE id = ?");
        $stmt->execute([$plan_id, $expiry, $user_id]);

        // Update session
        $_SESSION['plan_id'] = $plan_id;
        $_SESSION['plan_name'] = 'Pro';
        $_SESSION['is_pro'] = true;

        // Log activity
        logActivity($pdo, $user_id, 'subscription_upgraded', "Upgraded to Pro plan via Paystack (₦" . number_format($verified_amount) . ") — expires " . date('M j, Y', strtotime($expiry)), 'subscription', null);

        header('Location: dashboard.php?upgraded=1');
        exit;
    }
}

// If verification failed, redirect back to pricing
header('Location: pricing.php?error=verification_failed');
exit;
