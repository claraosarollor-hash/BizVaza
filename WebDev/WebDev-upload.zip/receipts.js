function toggleUserMenu(e) {
    e.stopPropagation();
    document.getElementById('userMenu').classList.toggle('show');
}
document.addEventListener('click', function() {
    var menu = document.getElementById('userMenu');
    if (menu) menu.classList.remove('show');
});
function showForm() {
    document.getElementById('formWrapper').classList.add('show');
    window.scrollTo({ top: document.getElementById('formWrapper').offsetTop - 20, behavior: 'smooth' });
}
function hideForm() {
    document.getElementById('formWrapper').classList.remove('show');
}

(function() {
    var editor = document.getElementById('rcptItemsEditor');
    var body = document.getElementById('rcptItemsBody');
    var invoiceField = document.querySelector('input[name="invoice_number"]');
    var amountField = document.querySelector('input[name="amount"]');
    var addBtn = document.getElementById('rcpAddItem');
    if (!editor || !body) return;

    function recalc() {
        var total = 0, hasItems = false;
        body.querySelectorAll('.rcp-item-row').forEach(function(row) {
            var qty = parseFloat(row.querySelector('.rcp-qty-input').value) || 0;
            var price = parseFloat((row.querySelector('.rcp-price-input').value || '').replace(/,/g, '')) || 0;
            var amt = Math.round(qty * price * 100) / 100;
            var name = (row.querySelector('input[name="item_name[]"]').value || '').trim();
            row.querySelector('.rcp-amount-input').value = amt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            if (name !== '' || qty > 0 || price > 0) hasItems = true;
            total += amt;
        });
        total = Math.round(total * 100) / 100;
        if (amountField) {
            amountField.readOnly = hasItems;
            if (hasItems) amountField.value = total.toFixed(2);
        }
    }

    function updateEditorState() {
        var hasInvoice = invoiceField && invoiceField.value.trim() !== '';
        editor.style.display = hasInvoice ? 'none' : 'block';
        if (hasInvoice) {
            if (amountField) amountField.readOnly = false;
        } else {
            recalc();
        }
    }

    body.addEventListener('input', recalc);
    body.addEventListener('click', function(e) {
        var btn = e.target.closest('.rcp-del-row');
        if (!btn) return;
        if (body.querySelectorAll('.rcp-item-row').length > 1) {
            btn.closest('.rcp-item-row').remove();
            recalc();
        }
    });
    if (addBtn) addBtn.addEventListener('click', function() {
        var rows = body.querySelectorAll('.rcp-item-row');
        var clone = rows[rows.length - 1].cloneNode(true);
        clone.querySelector('input[name="item_name[]"]').value = '';
        clone.querySelector('input[name="item_description[]"]').value = '';
        clone.querySelector('.rcp-qty-input').value = 1;
        clone.querySelector('.rcp-price-input').value = '';
        clone.querySelector('.rcp-amount-input').value = '0.00';
        body.appendChild(clone);
        recalc();
    });
    if (invoiceField) invoiceField.addEventListener('input', updateEditorState);
    updateEditorState();
})();
