<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

validate_csrf();

$user_id = $_SESSION['user_id'];

// Get Paystack secret key
$stmt = $pdo->prepare("SELECT `value` FROM settings WHERE `key` = ?");
$stmt->execute(['paystack_secret_key']);
$secret = $stmt->fetchColumn();
if (!$secret || strpos($secret, 'sk_live_') !== 0) {
    echo json_encode(['error' => 'Payment gateway not configured']);
    exit;
}

// Get plan price
$plan_id = intval($_POST['plan_id'] ?? 2);
$stmt = $pdo->prepare("SELECT * FROM plans WHERE id = ?");
$stmt->execute([$plan_id]);
$plan = $stmt->fetch();
if (!$plan || $plan['price'] <= 0) {
    echo json_encode(['error' => 'Invalid plan']);
    exit;
}

// Get user email
$email = $_SESSION['email'];

// Generate unique reference
$reference = 'BF-' . $user_id . '-' . time();

// Amount in kobo
$amount = (int)round($plan['price'] * 100);

// Initialize Paystack transaction
$url = 'https://api.paystack.co/transaction/initialize';
$data = [
    'email' => $email,
    'amount' => $amount,
    'reference' => $reference,
    'currency' => 'NGN',
    'metadata' => [
        'user_id' => $user_id,
        'plan_id' => $plan_id,
        'plan_name' => $plan['name'],
        'custom_fields' => [
            [
                'display_name' => 'User ID',
                'variable_name' => 'user_id',
                'value' => $user_id,
            ],
            [
                'display_name' => 'Plan',
                'variable_name' => 'plan_name',
                'value' => $plan['name'],
            ]
        ]
    ]
];

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($data),
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $secret,
        'Content-Type: application/json',
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => true,
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$result = json_decode($response, true);

if ($http_code === 200 && $result['status'] === true) {
    // Store pending payment record
    $stmt = $pdo->prepare("INSERT INTO subscription_payments (user_id, reference, amount, method, status, paystack_reference) VALUES (?, ?, ?, 'paystack', 'pending', ?)");
    $stmt->execute([$user_id, $reference, $plan['price'], $reference]);

    echo json_encode([
        'success' => true,
        'authorization_url' => $result['data']['authorization_url'],
        'reference' => $reference,
    ]);
} else {
    echo json_encode([
        'error' => $result['message'] ?? 'Payment initialization failed',
    ]);
}
