<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
$activePage = 'help';

if (!adminCan('help')) { $_SESSION['flash'] = 'You do not have access to that page.'; header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status']) && isset($_POST['id'])) {
    validate_csrf();
    $id = intval($_POST['id']);
    $status = $_POST['status'];
    if (in_array($status, ['contacted', 'resolved'])) {
        $pdo->prepare("UPDATE help_requests SET status = ? WHERE id = ?")->execute([$status, $id]);
    }
}

$stmt = $pdo->query("SELECT h.*, u.full_name as user_name FROM help_requests h LEFT JOIN users u ON h.user_id = u.id ORDER BY h.created_at DESC");
$requests = $stmt->fetchAll();
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>BizFlow — Admin Help Requests</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="../assets/css/styles.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;background:#f0f2f5;display:flex;min-height:100vh;font-size:13px;color:#0f172a}
.sidebar{width:210px;min-width:210px;background:#0d2141;color:#fff;display:flex;flex-direction:column}
.logo{display:flex;align-items:center;gap:10px;padding:22px 18px 26px}
.logo-icon{width:36px;height:36px;background:#b45309;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.logo-text .brand{display:block;font-size:15px;font-weight:700;letter-spacing:.5px;color:#fff}
.nav{flex:1;padding:0 10px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:8px;cursor:pointer;color:#8da0c0;font-size:13px;margin-bottom:2px;transition:background .15s;text-decoration:none}
.nav-item:hover{background:#142a4b;color:#fff}
.nav-item.active{background:#b45309;color:#fff}
.nav-item svg{flex-shrink:0;opacity:.85}
.nav-item.active svg{opacity:1}
.nav-help{margin:8px 10px 16px;background:#0b1e38;border-radius:8px;padding:12px 10px;display:flex;align-items:center;gap:10px;text-decoration:none;color:#7a8fa6}
.nav-help:hover{background:#142a4b}
.nav-help svg{flex-shrink:0;color:#7a8fa6}
.nav-help-text .ht{display:block;font-size:12px;font-weight:500;color:#fff}
.nav-help-text .hs{display:block;font-size:11px;color:#7a8fa6}
.nav-help .arr{margin-left:auto;color:#7a8fa6}
.main{flex:1;display:flex;flex-direction:column;min-width:0}
.topbar{background:#fff;border-bottom:1px solid #e5e7eb;padding:16px 28px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.topbar h2{font-size:18px;font-weight:600;color:#0f172a}
.topbar p{font-size:12px;color:#8da0c0;margin-top:2px}
.content{padding:28px 24px 0;flex:1}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:18px 16px;margin-bottom:20px}
.card-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.card-head h3{font-size:14px;font-weight:600;color:#0f172a}
table{width:100%;border-collapse:collapse}
thead th{font-size:11px;color:#8da0c0;font-weight:500;text-align:left;padding:8px 10px;background:#fafbfc;border-bottom:1px solid #eef0f4;white-space:nowrap}
tbody td{padding:10px;font-size:12px;color:#3a4559;border-bottom:1px solid #f3f4f6}
tbody tr:last-child td{border-bottom:none}
tbody tr:hover{background:#fafbfd}
.badge{display:inline-block;padding:3px 10px;border-radius:100px;font-size:11px;font-weight:600}
.b-pending{background:#fff7ed;color:#b45309}
.b-contacted{background:#e0f2fe;color:#0369a1}
.b-resolved{background:#d1fae5;color:#059669}
.btn{display:inline-flex;padding:4px 10px;border-radius:5px;font-size:10px;font-weight:500;cursor:pointer;border:1px solid #d0d6df;background:#fff;color:#1a2332;text-decoration:none;font-family:'Inter',sans-serif}
.btn:hover{background:#f5f6f8}
.msg-cell{max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#64748b}

</style>
</head>
<body>
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<div class="main">
<div class="topbar"><div><button class="hamburger-btn" onclick="toggleSidebar()"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg></button><h2>Help Requests</h2><p><?= count($requests) ?> total</p></div></div>
<div class="content">

<div class="card">
<div class="card-head"><h3>All Requests</h3></div>
<div class="table-responsive">
<table>
<thead><tr><th>Name</th><th>Phone</th><th>Message</th><th>Callback</th><th>Status</th><th>Submitted</th><th></th></tr></thead>
<tbody>
<?php if (count($requests) > 0): ?>
<?php foreach ($requests as $r): ?>
<tr>
<td><?= htmlspecialchars($r['name']) ?><?= $r['user_name'] ? ' <span style="color:#64748b;font-size:10px">(' . htmlspecialchars($r['user_name']) . ')</span>' : '' ?></td>
<td><?= htmlspecialchars($r['phone']) ?></td>
<td class="msg-cell" title="<?= htmlspecialchars($r['message'] ?? '') ?>"><?= htmlspecialchars($r['message'] ?? '—') ?></td>
<td><?= $r['callback_date'] ? date('M j', strtotime($r['callback_date'])) . ($r['callback_time'] ? ' ' . substr($r['callback_time'], 0, 5) : '') : '—' ?></td>
<td><span class="badge b-<?= $r['status'] ?? 'pending' ?>"><?= $r['status'] ?? 'pending' ?></span></td>
<td><?= date('M j, Y g:i A', strtotime($r['created_at'])) ?></td>
<td>
<?php if (($r['status'] ?? 'pending') === 'pending'): ?>
<form method="POST" style="display:inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['id'] ?>"><button type="submit" name="status" value="contacted" class="btn">Contacted</button></form>
<?php endif; ?>
<?php if (($r['status'] ?? 'pending') !== 'resolved'): ?>
<form method="POST" style="display:inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['id'] ?>"><button type="submit" name="status" value="resolved" class="btn">Resolved</button></form>
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr><td colspan="7" style="text-align:center;padding:24px;color:#94a3b8">No help requests</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
</div>
<script src="../assets/js/app.js"></script>
</body>
</html>