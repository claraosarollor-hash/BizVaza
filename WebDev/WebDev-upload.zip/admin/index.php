<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
$activePage = 'dashboard';

$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$freeUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE plan_id = 1 OR plan_id IS NULL")->fetchColumn();
$proUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE plan_id = 2")->fetchColumn();
$newThisWeek = $pdo->query("SELECT COUNT(*) FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetchColumn();
$totalInvoices = $pdo->query("SELECT COUNT(*) FROM invoices")->fetchColumn();
$totalReceipts = $pdo->query("SELECT COUNT(*) FROM payments WHERE status = 'paid'")->fetchColumn();
$totalRevenue = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status = 'paid'")->fetchColumn();
$pendingUpgrades = $pdo->query("SELECT COUNT(*) FROM subscription_payments WHERE status = 'pending'")->fetchColumn();
$teamCount = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
$recentUsers = $pdo->query("SELECT id, full_name, business_name, email, plan_id, created_at FROM users ORDER BY created_at DESC LIMIT 10")->fetchAll();
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>BizFlow — Admin Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="../assets/css/styles.css">
<style>
.main{flex:1;display:flex;flex-direction:column;min-width:0}
.content{padding:28px 24px 0;flex:1}
.avatar-init{width:28px;height:28px;border-radius:50%;background:#fff7ed;display:inline-flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#b45309;flex-shrink:0}
.user-cell{display:flex;align-items:center;gap:8px}
.plan-bar{display:flex;gap:0;border-radius:8px;overflow:hidden;height:20px;margin-top:8px;width:100%}
.plan-bar .seg{display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:600;color:#fff}
.plan-bar .seg.free{background:#fde68a;color:#92400e}
.plan-bar .seg.pro{background:#059669}
.b-free{background:#fff7ed;color:#b45309}
@media(max-width:1100px){.stat-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:600px){.stat-grid{grid-template-columns:1fr}}
</style>
</head>
<body class="dashboard-body">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<div class="main">
<div class="topbar">
<div>
<button class="hamburger-btn" onclick="toggleSidebar()"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg></button>
<h2>Admin Dashboard</h2>
<p>Overview of your BizFlow platform</p>
</div>
<div style="font-size:12px;color:#64748b"><?= htmlspecialchars($_SESSION['full_name']) ?></div>
</div>
<div class="content">
<div class="stat-grid">
<div class="stat-card">
<div class="stat-icon si-blue">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#b45309" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
</div>
<div>
<span class="stat-label">Total Users</span>
<div class="stat-val"><?= $totalUsers ?></div>
<div style="font-size:11px;color:#8da0c0;margin-top:4px"><?= $newThisWeek ?> new this week</div>
<div class="plan-bar">
<?php $total = max($totalUsers, 1); $freePct = round($freeUsers / $total * 100); $proPct = 100 - $freePct; ?>
<div class="seg free" style="width:<?= $freePct ?>%"><?= $freePct > 10 ? 'Free '.$freeUsers : '' ?></div>
<div class="seg pro" style="width:<?= $proPct ?>%"><?= $proPct > 10 ? 'Pro '.$proUsers : '' ?></div>
</div>
</div>
</div>
<div class="stat-card">
<div class="stat-icon si-green">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
</div>
<div>
<span class="stat-label">Free Users</span>
<div class="stat-val"><?= $freeUsers ?></div>
</div>
</div>
<div class="stat-card">
<div class="stat-icon si-purple">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
</div>
<div>
<span class="stat-label">Pro Users</span>
<div class="stat-val"><?= $proUsers ?></div>
</div>
</div>
<div class="stat-card">
<div class="stat-icon si-green">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>
</div>
<div>
<span class="stat-label">Team</span>
<div class="stat-val"><?= $teamCount ?></div>
<div style="font-size:11px;color:#8da0c0;margin-top:4px"><?php if (adminCan('team')): ?><a href="team.php" style="color:#b45309;text-decoration:none">Manage &rarr;</a><?php else: ?>Admin staff<?php endif; ?></div>
</div>
</div>
<div class="stat-card">
<div class="stat-icon si-orange">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#b45309" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
</div>
<div>
<span class="stat-label">Total Invoices</span><div class="stat-val"><?= $totalInvoices ?></div>
</div>
</div>
<div class="stat-card">
<div class="stat-icon si-purple">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2" /><rect x="9" y="3" width="6" height="4" rx="1" /><path d="M9 12h6M9 16h4" /></svg>
</div>
<div>
<span class="stat-label">Total Receipts</span>
<div class="stat-val"><?= $totalReceipts ?></div>
</div>
</div>
<div class="stat-card">
<div class="stat-icon si-blue">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#b45309" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
</div>
<div>
<span class="stat-label">Total Revenue</span>
<div class="stat-val">₦<?= number_format($totalRevenue, 2) ?></div>
<div style="font-size:11px;color:#8da0c0;margin-top:4px">From paid receipts</div>
</div>
</div>
<?php if ($pendingUpgrades > 0): ?>
<a href="upgrade-requests.php" style="text-decoration:none">
<div class="stat-card" style="border-color:#fed7aa;background:#fff7ed">
<div class="stat-icon si-orange">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
</div>
<div>
<span class="stat-label">Pending Upgrades</span>
<div class="stat-val" style="color:#dc2626"><?= $pendingUpgrades ?></div>
<div style="font-size:11px;color:#b45309;margin-top:4px">Review &amp; approve <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px"><polyline points="9 18 15 12 9 6"/></svg></div>
</div>
</div>
</a>
<?php endif; ?>
</div>

<div class="card">
<div class="card-head"><h3>Recent Registrations</h3></div>
<div class="table-responsive"><table>
<thead><tr><th>User</th><th>Business</th><th>Email</th><th>Plan</th><th>Joined</th></tr></thead>
<tbody>
<?php if (count($recentUsers) > 0): ?>
<?php foreach ($recentUsers as $u): ?>
<tr>
<td><div class="user-cell"><span class="avatar-init"><?= htmlspecialchars(getAvatarInitials($u['full_name'])) ?></span> <?= htmlspecialchars($u['full_name']) ?></div></td>
<td><?= htmlspecialchars($u['business_name']) ?></td>
<td><?= htmlspecialchars($u['email']) ?></td>
<td><span class="badge <?= ($u['plan_id'] ?? 1) == 2 ? 'b-pro' : 'b-free' ?>"><?= ($u['plan_id'] ?? 1) == 2 ? 'Pro' : 'Free' ?></span></td>
<td><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr><td colspan="5" style="text-align:center;padding:24px;color:#94a3b8">No users yet</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
</div>
<script src="../assets/js/app.js"></script>
</body>
</html>