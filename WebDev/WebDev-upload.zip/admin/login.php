<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/../includes/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validate_csrf();
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            if (!empty($user['suspended'])) {
                $error = 'Invalid email or password.';
            } elseif (password_verify($password, $user['password'])) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['business_name'] = $user['business_name'];
                $_SESSION['business_abbr'] = $user['business_abbr'] ?? '';
                $_SESSION['email'] = $user['email'];
                $_SESSION['avatar_initials'] = getAvatarInitials($user['full_name']);
                $_SESSION['role'] = 'admin';
                header('Location: index.php');
                exit;
            } else {
                $error = 'Invalid email or password.';
            }
        } else {
            $error = 'Invalid email or password.';
        }
    } else {
        $error = 'Please fill in all fields.';
    }
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>BizFlow — Admin Login</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="../assets/css/styles.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:"Inter",sans-serif;background:#0d2141;display:flex;justify-content:center;align-items:center;min-height:100vh;padding:24px}
.auth-wrap{width:400px;max-width:100%}
.auth-card{background:#fff;border-radius:16px;padding:40px 36px 36px;box-shadow:0 8px 32px rgba(0,0,0,.2)}
.auth-logo{display:flex;align-items:center;gap:10px;justify-content:center;margin-bottom:28px;text-decoration:none}
.auth-logo-icon{width:40px;height:40px;background:#0d2141;border-radius:10px;display:flex;align-items:center;justify-content:center}
.auth-logo-icon svg{width:22px;height:22px}
.auth-logo-text{font-size:20px;font-weight:800;color:#0f172a;letter-spacing:.02em}
.admin-badge{display:inline-block;background:#d1fae5;color:#059669;font-size:11px;font-weight:700;padding:3px 10px;border-radius:100px;text-transform:uppercase;letter-spacing:.3px;margin-bottom:20px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#333;margin-bottom:6px}
.form-group input{width:100%;padding:12px 14px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;font-family:"Inter",sans-serif;color:#111;background:#fff;outline:none;transition:border-color .15s}
.form-group input:focus{border-color:#b45309}
.form-group input::placeholder{color:#aaa}
.auth-btn{width:100%;padding:13px;background:#b45309;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:700;font-family:"Inter",sans-serif;cursor:pointer;margin-top:8px}
.auth-btn:hover{background:#92400e}
.error{background:#fef2f2;color:#dc2626;padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:18px;border:1px solid #fecaca}
.back-link{display:block;text-align:center;margin-top:20px;font-size:13px;color:#64748b;text-decoration:none}
.back-link:hover{color:#0f172a}
</style>
</head>
<body>
<div class="auth-wrap">
<div class="auth-card">
<div style="text-align:center">
<div class="admin-badge">Admin</div>
</div>
<a class="auth-logo" href="#">
<div class="auth-logo-icon">
<svg viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 2L4 11h7l-2 7 9-10h-7l2-8z" fill="#fff"/></svg>
</div>
<span class="auth-logo-text">BizFlow</span>
</a>
<h2 style="font-size:20px;font-weight:700;color:#0f172a;text-align:center;margin-bottom:24px">Admin Portal</h2>
<?php if ($error): ?>
<div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<form method="post">
<?= csrf_field() ?>
<div class="form-group">
<label for="email">Admin Email</label>
<input type="email" id="email" name="email" placeholder="admin@bizflow.com" required/>
</div>
<div class="form-group">
<label for="password">Password</label>
<input type="password" id="password" name="password" placeholder="Enter password" required/>
</div>
<button type="submit" class="auth-btn">Sign In</button>
</form>
<a href="../index.html" class="back-link">&larr; Back to Main Site</a>
</div>
</div>
</body>
</html>
