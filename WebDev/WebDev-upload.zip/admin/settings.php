<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
$activePage = 'settings';

if (!adminCan('settings')) { $_SESSION['flash'] = 'You do not have access to that page.'; header('Location: index.php'); exit; }

$flash = '';
$settings = [];
$stmt = $pdo->query("SELECT `key`, `value` FROM settings");
while ($row = $stmt->fetch()) { $settings[$row['key']] = $row['value']; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    validate_csrf();
    foreach (['payment_bank_name', 'payment_account_name', 'payment_account_number', 'paystack_public_key', 'paystack_secret_key', 'smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'mail_from', 'mail_from_name'] as $k) {
        $v = trim($_POST[$k] ?? '');
        if (($k === 'paystack_secret_key' || $k === 'smtp_pass') && $v === '') continue;
        $pdo->prepare("INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)")->execute([$k, $v]);
        $settings[$k] = $v;
    }
    $flash = 'Settings saved.';
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>BizFlow — Admin Settings</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="../assets/css/styles.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;background:#f0f2f5;display:flex;min-height:100vh;font-size:13px;color:#0f172a}
.main{flex:1;display:flex;flex-direction:column;min-width:0}
.topbar{background:#fff;border-bottom:1px solid #e5e7eb;padding:16px 28px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.topbar h2{font-size:18px;font-weight:600;color:#0f172a}
.content{padding:28px 24px 0;flex:1;max-width:600px}
.flash{background:#d1fae5;border:1px solid #a7f3d0;color:#059669;padding:10px 16px;border-radius:8px;font-size:13px;margin-bottom:16px}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:18px 16px;margin-bottom:20px}
.card-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.card-head h3{font-size:14px;font-weight:600;color:#0f172a}
label{display:block;font-size:12px;font-weight:500;color:#3a4a5c;margin-bottom:4px;margin-top:10px}
label:first-of-type{margin-top:0}
input{width:100%;padding:9px 12px;border:1px solid #d0d6df;border-radius:7px;font-size:13px;font-family:'Inter',sans-serif;outline:none;background:#fff}
input:focus{border-color:#b45309}
.btn{display:inline-flex;align-items:center;padding:9px 16px;border-radius:7px;font-size:13px;font-weight:500;cursor:pointer;border:1px solid #d0d6df;background:#fff;color:#1a2332;font-family:'Inter',sans-serif;margin-top:14px}
.btn:hover{background:#f5f6f8}
.btn-primary{background:#b45309;color:#fff;border-color:#b45309}
.btn-primary:hover{background:#92400e}
.hint{font-size:11px;color:#64748b;margin-top:2px}

</style>
</head>
<body>
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<div class="main">
<div class="topbar"><div><button class="hamburger-btn" onclick="toggleSidebar()"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg></button><h2>Settings</h2></div></div>
<div class="content">
<?php if ($flash): ?><div class="flash"><?= htmlspecialchars($flash) ?></div><?php endif; ?>
<form method="post">
<?= csrf_field() ?>
<input type="hidden" name="save_settings" value="1">
<div class="card">
<div class="card-head"><h3>Payment & Paystack Settings</h3></div>
<p style="font-size:12px;color:#64748b;margin-bottom:8px">Bank details are shown on the pricing page. Online card payments activate when LIVE Paystack keys are saved; test keys keep them off.</p>
<label>Bank Name</label>
<input type="text" name="payment_bank_name" value="<?= htmlspecialchars($settings['payment_bank_name'] ?? '') ?>">
<label>Account Name</label>
<input type="text" name="payment_account_name" value="<?= htmlspecialchars($settings['payment_account_name'] ?? '') ?>">
<label>Account Number</label>
<input type="text" name="payment_account_number" value="<?= htmlspecialchars($settings['payment_account_number'] ?? '') ?>">
<hr style="margin:16px 0;border:none;border-top:1px solid #e5e7eb">
<label>Paystack Public Key</label>
<input type="text" name="paystack_public_key" value="<?= htmlspecialchars($settings['paystack_public_key'] ?? '') ?>" placeholder="pk_live_xxxxxxxxx">
<label>Paystack Secret Key</label>
<input type="password" name="paystack_secret_key" value="" placeholder="Leave blank to keep current" autocomplete="new-password">
<div class="hint">Leave blank to keep the current key.</div>
<button class="btn btn-primary" type="submit">Save Settings</button>
</div>
<div class="card">
<div class="card-head"><h3>SMTP Email Settings</h3></div>
<p style="font-size:12px;color:#64748b;margin-bottom:8px">Used to send password reset emails. For Gmail use <strong>smtp.gmail.com</strong>, port <strong>587</strong>, and an App Password.</p>
<label>SMTP Host</label>
<input type="text" name="smtp_host" value="<?= htmlspecialchars($settings['smtp_host'] ?? '') ?>" placeholder="smtp.gmail.com">
<label>SMTP Port</label>
<input type="text" name="smtp_port" value="<?= htmlspecialchars($settings['smtp_port'] ?? '') ?>" placeholder="587">
<label>SMTP Username</label>
<input type="text" name="smtp_user" value="<?= htmlspecialchars($settings['smtp_user'] ?? '') ?>" placeholder="you@gmail.com">
<label>SMTP Password</label>
<input type="password" name="smtp_pass" value="" placeholder="App password" autocomplete="new-password">
<div class="hint">Leave blank to keep the current password. For Gmail you need an App Password (enable 2-Step Verification, then create one).</div>
<label>From Email</label>
<input type="text" name="mail_from" value="<?= htmlspecialchars($settings['mail_from'] ?? '') ?>" placeholder="no-reply@bizflow.ng">
<label>From Name</label>
<input type="text" name="mail_from_name" value="<?= htmlspecialchars($settings['mail_from_name'] ?? '') ?>" placeholder="BizFlow">
<button class="btn btn-primary" type="submit">Save Settings</button>
</div>
</form>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
</div>
<script src="../assets/js/app.js"></script>
</body>
</html>