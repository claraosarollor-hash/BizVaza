<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
$activePage = 'revenue';

if (!adminCan('revenue')) { $_SESSION['flash'] = 'You do not have access to that page.'; header('Location: index.php'); exit; }

$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';

$where = "WHERE p.status = 'paid'";
$params = [];
if ($from) { $where .= " AND p.payment_date >= ?"; $params[] = $from; }
if ($to) { $where .= " AND p.payment_date <= ?"; $params[] = $to; }

$totalRevenue = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM payments p $where");
$totalRevenue->execute($params);
$totalRevenue = $totalRevenue->fetchColumn();

$monthly = $pdo->prepare("SELECT DATE_FORMAT(p.payment_date, '%Y-%m') as month, COUNT(*) as invoice_count, COALESCE(SUM(p.amount), 0) as total FROM payments p $where GROUP BY month ORDER BY month DESC LIMIT 24");
$monthly->execute($params);
$monthly = $monthly->fetchAll();

if (isset($_GET['export'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=revenue-export.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Month', 'Invoice Count', 'Total Amount (₦)']);
    foreach ($monthly as $m) { fputcsv($out, [$m['month'], $m['invoice_count'], number_format($m['total'], 2)]); }
    fclose($out);
    exit;
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>BizFlow — Admin Revenue</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="../assets/css/styles.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;background:#f0f2f5;display:flex;min-height:100vh;font-size:13px;color:#0f172a}
.main{flex:1;display:flex;flex-direction:column;min-width:0}
.topbar{background:#fff;border-bottom:1px solid #e5e7eb;padding:16px 28px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.topbar h2{font-size:18px;font-weight:600;color:#0f172a}
.content{padding:28px 24px 0;flex:1;max-width:800px}
.stat-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px;margin-bottom:20px}
.stat-card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:18px 16px;display:flex;align-items:center;gap:14px}
.stat-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.si-blue{background:#fff7ed}
.si-green{background:#d1fae5}
.stat-label{font-size:11px;color:#8da0c0;display:block;margin-bottom:4px;letter-spacing:.3px}
.stat-val{font-size:22px;font-weight:700;color:#0f172a;line-height:1.1}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:18px 16px;margin-bottom:20px}
.card-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.card-head h3{font-size:14px;font-weight:600;color:#0f172a}
table{width:100%;border-collapse:collapse}
thead th{font-size:11px;color:#8da0c0;font-weight:500;text-align:left;padding:8px 10px;background:#fafbfc;border-bottom:1px solid #eef0f4;white-space:nowrap}
tbody td{padding:10px;font-size:12px;color:#3a4559;border-bottom:1px solid #f3f4f6}
tbody tr:last-child td{border-bottom:none}
tbody tr:hover{background:#fafbfd}
.filter-row{display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap}
.filter-row label{font-size:11px;font-weight:500;color:#3a4a5c;display:block;margin-bottom:2px}
.filter-row input{padding:7px 10px;border:1px solid #d0d6df;border-radius:6px;font-size:12px;font-family:'Inter',sans-serif;outline:none;background:#fff}
.filter-row input:focus{border-color:#b45309}
.btn{display:inline-flex;align-items:center;padding:7px 14px;border-radius:6px;font-size:12px;font-weight:500;cursor:pointer;border:1px solid #d0d6df;background:#fff;color:#1a2332;text-decoration:none;font-family:'Inter',sans-serif}
.btn:hover{background:#f5f6f8}
.btn-primary{background:#b45309;color:#fff;border-color:#b45309}
.btn-primary:hover{background:#92400e}
@media(max-width:700px){.stat-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<div class="main">
<div class="topbar"><div><button class="hamburger-btn" onclick="toggleSidebar()"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg></button><h2>Revenue</h2></div></div>
<div class="content">

<div class="stat-grid">
<div class="stat-card">
<div class="stat-icon si-blue">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#b45309" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
</div>
<div>
<span class="stat-label">Total Revenue (Paid Receipts)</span>
<div class="stat-val">₦<?= number_format($totalRevenue, 2) ?></div>
</div>
</div>
</div>

<div class="card">
<div class="card-head"><h3>Filter &amp; Export</h3></div>
<form class="filter-row">
<label>From <input type="date" name="from" value="<?= htmlspecialchars($from) ?>"></label>
<label>To <input type="date" name="to" value="<?= htmlspecialchars($to) ?>"></label>
<button class="btn btn-primary" type="submit">Filter</button>
<?php if ($from || $to): ?><a href="revenue.php" class="btn">Clear</a><?php endif; ?>
<a href="?export=1&from=<?= urlencode($from) ?>&to=<?= urlencode($to) ?>" class="btn">CSV Export</a>
</form>
</div>

<div class="card">
<div class="card-head"><h3>Monthly Breakdown</h3></div>
<div class="table-responsive">
<table>
<thead><tr><th>Month</th><th>Invoices Paid</th><th>Total Amount</th></tr></thead>
<tbody>
<?php if (count($monthly) > 0): ?>
<?php foreach ($monthly as $m): ?>
<tr>
<td><?= htmlspecialchars($m['month']) ?></td>
<td><?= $m['invoice_count'] ?></td>
<td>₦<?= number_format($m['total'], 2) ?></td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr><td colspan="3" style="text-align:center;padding:24px;color:#94a3b8">No data</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
</div>
<script src="../assets/js/app.js"></script>
</body>
</html>