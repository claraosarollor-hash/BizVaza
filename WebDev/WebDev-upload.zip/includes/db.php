<?php
if (__FILE__ === $_SERVER['SCRIPT_FILENAME']) { header($_SERVER['SERVER_PROTOCOL'].' 403 Forbidden'); exit; }
require_once __DIR__ . '/config.php';

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('BizFlow DB connection failed: ' . $e->getMessage());
    die('A database error occurred. Please try again later.');
}

$stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = " . $pdo->quote(DB_NAME) . " AND TABLE_NAME = 'users' AND COLUMN_NAME = 'admin_pages'");
if ((int)$stmt->fetchColumn() === 0) {
    $pdo->exec("ALTER TABLE users ADD COLUMN admin_pages TEXT NULL AFTER role");
}

$stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = " . $pdo->quote(DB_NAME) . " AND TABLE_NAME = 'users' AND COLUMN_NAME = 'trial_ends_at'");
if ((int)$stmt->fetchColumn() === 0) {
    $pdo->exec("ALTER TABLE users ADD COLUMN trial_ends_at DATETIME NULL AFTER plan_expires_at");
    $pdo->exec("UPDATE users SET trial_ends_at = DATE_ADD(NOW(), INTERVAL 3 MONTH) WHERE trial_ends_at IS NULL AND role != 'admin'");
}

$pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY user_id (user_id),
    KEY is_read (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// --- Data-integrity migrations: document numbering + receipt/invoice integrity ---

// Per-user monotonic document number counters (numbers are never reused after deletion).
$pdo->exec("CREATE TABLE IF NOT EXISTS number_sequences (
    user_id INT NOT NULL,
    doc_type ENUM('invoice','receipt') NOT NULL,
    last_value INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, doc_type),
    CONSTRAINT fk_numseq_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Seed counters from existing highest numeric suffixes (only when the table is brand new).
$stmt = $pdo->query("SELECT COUNT(*) FROM number_sequences");
$numseq_fresh = ((int)$stmt->fetchColumn() === 0);
if ($numseq_fresh) {
    $pdo->exec("INSERT IGNORE INTO number_sequences (user_id, doc_type, last_value)
        SELECT user_id, 'invoice', COALESCE(MAX(CAST(SUBSTRING_INDEX(invoice_number,'-',-1) AS UNSIGNED)),0)
        FROM invoices GROUP BY user_id");
    $pdo->exec("INSERT IGNORE INTO number_sequences (user_id, doc_type, last_value)
        SELECT user_id, 'receipt', COALESCE(MAX(CAST(SUBSTRING_INDEX(receipt_number,'-',-1) AS UNSIGNED)),0)
        FROM payments GROUP BY user_id");
}

// Nullable generated key so standalone receipts (invoice_number = '') don't collide
// in the per-invoice uniqueness index (multiple NULLs are allowed in a UNIQUE index).
$stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = " . $pdo->quote(DB_NAME) . " AND TABLE_NAME = 'payments' AND COLUMN_NAME = 'invoice_key'");
if ((int)$stmt->fetchColumn() === 0) {
    $pdo->exec("ALTER TABLE payments ADD COLUMN invoice_key VARCHAR(50) GENERATED ALWAYS AS (NULLIF(invoice_number,'')) STORED AFTER invoice_number");
}

// Unique integrity indexes (guarded + best-effort so pre-existing duplicates elsewhere don't break the app).
// Multiple receipts per invoice are allowed while it is not fully paid,
// so the strict per-invoice uniqueness index is dropped (guarded + idempotent).
$uq_count = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = " . $pdo->quote(DB_NAME) . " AND TABLE_NAME = 'payments' AND INDEX_NAME = 'uq_pay_user_invoice'")->fetchColumn();
if ((int)$uq_count > 0) {
    try { $pdo->exec("ALTER TABLE payments DROP INDEX uq_pay_user_invoice"); }
    catch (PDOException $e) { error_log('BizFlow migration drop uq_pay_user_invoice failed: ' . $e->getMessage()); }
}
$uq_count = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = " . $pdo->quote(DB_NAME) . " AND TABLE_NAME = 'payments' AND INDEX_NAME = 'uq_pay_receipt'")->fetchColumn();
if ((int)$uq_count === 0) {
    try { $pdo->exec("ALTER TABLE payments ADD UNIQUE INDEX uq_pay_receipt (user_id, receipt_number)"); }
    catch (PDOException $e) { error_log('BizFlow migration uq_pay_receipt failed: ' . $e->getMessage()); }
}
$uq_count = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = " . $pdo->quote(DB_NAME) . " AND TABLE_NAME = 'invoices' AND INDEX_NAME = 'uq_inv_number'")->fetchColumn();
if ((int)$uq_count === 0) {
    try { $pdo->exec("ALTER TABLE invoices ADD UNIQUE INDEX uq_inv_number (user_id, invoice_number)"); }
    catch (PDOException $e) { error_log('BizFlow migration uq_inv_number failed: ' . $e->getMessage()); }
}

// Keep the per-user counter synced to the highest existing numeric suffix.
function syncDocCounter(PDO $pdo, int $user_id, string $type): void {
    $stmt = $pdo->prepare("INSERT IGNORE INTO number_sequences (user_id, doc_type, last_value) VALUES (?, ?, 0)");
    $stmt->execute([$user_id, $type]);
    $numCol = $type === 'invoice' ? 'invoice_number' : 'receipt_number';
    $table = $type === 'invoice' ? 'invoices' : 'payments';
    $stmt = $pdo->prepare("UPDATE number_sequences SET last_value = GREATEST(last_value, COALESCE((SELECT MAX(CAST(SUBSTRING_INDEX($numCol,'-',-1) AS UNSIGNED)) FROM $table WHERE user_id = ?), 0)) WHERE user_id = ? AND doc_type = ?");
    $stmt->execute([$user_id, $user_id, $type]);
}

function formatDocNumber(string $type, string $abbr, int $seq): string {
    $prefix = $type === 'invoice' ? 'INV' : 'RCP';
    return $prefix . '-' . $abbr . '-' . date('Y') . '-' . str_pad($seq, 3, '0', STR_PAD_LEFT);
}

// Suggested next number (peek only, does not consume).
function nextDocNumber(PDO $pdo, int $user_id, string $type, string $abbr): string {
    syncDocCounter($pdo, $user_id, $type);
    $stmt = $pdo->prepare("SELECT last_value FROM number_sequences WHERE user_id = ? AND doc_type = ?");
    $stmt->execute([$user_id, $type]);
    return formatDocNumber($type, $abbr, intval($stmt->fetchColumn()) + 1);
}

// Reserve and return the next number atomically (never reused after deletion).
function consumeDocNumber(PDO $pdo, int $user_id, string $type, string $abbr): string {
    syncDocCounter($pdo, $user_id, $type);
    $stmt = $pdo->prepare("UPDATE number_sequences SET last_value = LAST_INSERT_ID(last_value + 1) WHERE user_id = ? AND doc_type = ?");
    $stmt->execute([$user_id, $type]);
    return formatDocNumber($type, $abbr, intval($pdo->lastInsertId()));
}

// Invoice amount and cumulative paid total (status = 'paid' only) for the current user.
function invoicePaymentTotals(PDO $pdo, int $user_id, string $invoice_number): array {
    $stmt = $pdo->prepare("SELECT amount FROM invoices WHERE invoice_number = ? AND user_id = ? LIMIT 1");
    $stmt->execute([$invoice_number, $user_id]);
    $amount = floatval($stmt->fetchColumn());
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(p.amount), 0) FROM payments p WHERE p.invoice_number = ? AND p.user_id = ? AND p.status = 'paid'");
    $stmt->execute([$invoice_number, $user_id]);
    $paid = floatval($stmt->fetchColumn());
    return ['amount' => $amount, 'paid_sum' => $paid, 'remaining' => max(0, $amount - $paid)];
}

function getProPlan(PDO $pdo) {
    $stmt = $pdo->prepare("SELECT * FROM plans WHERE slug = 'pro' LIMIT 1");
    $stmt->execute();
    $pro = $stmt->fetch();
    if (!$pro) {
        $pro = $pdo->query("SELECT * FROM plans WHERE is_active = 1 ORDER BY price ASC LIMIT 1")->fetch();
    }
    return $pro ?: null;
}
