<?php
if (__FILE__ === $_SERVER['SCRIPT_FILENAME']) { header($_SERVER['SERVER_PROTOCOL'].' 403 Forbidden'); exit; }
function logActivity($pdo, $user_id, $action_type, $description, $reference_type = null, $reference_id = null) {
    $stmt = $pdo->prepare("INSERT INTO activity_log (user_id, action_type, description, reference_type, reference_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $action_type, $description, $reference_type, $reference_id]);

    $titles = [
        'item_added' => 'Item Added',
        'item_updated' => 'Item Updated',
        'item_deleted' => 'Item Deleted',
        'customer_added' => 'Customer Added',
        'customer_updated' => 'Customer Updated',
        'customer_deleted' => 'Customer Deleted',
        'invoice_created' => 'Invoice Created',
        'invoice_updated' => 'Invoice Updated',
        'invoice_deleted' => 'Invoice Deleted',
        'payment_recorded' => 'Payment Received',
        'payment_updated' => 'Payment Updated',
        'payment_deleted' => 'Payment Deleted',
        'subscription_upgraded' => 'Subscription Upgraded',
        'upgrade_request_submitted' => 'Upgrade Request',
        'review_submitted' => 'Review Submitted',
    ];
    $title = $titles[$action_type] ?? ucwords(str_replace('_', ' ', $action_type));
    addNotification($pdo, $user_id, $title, $description);
}
