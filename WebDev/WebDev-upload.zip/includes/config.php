<?php
if (__FILE__ === $_SERVER['SCRIPT_FILENAME']) { header($_SERVER['SERVER_PROTOCOL'].' 403 Forbidden'); exit; }
$sessionLifetime = 7 * 86400;
ini_set('session.gc_maxlifetime', (string)$sessionLifetime);
session_set_cookie_params([
    'lifetime' => $sessionLifetime,
    'httponly' => true,
    'samesite' => 'Strict',
    'secure' => !empty($_SERVER['HTTPS']),
]);
session_start();
date_default_timezone_set('Africa/Lagos');
error_reporting(E_ALL);
ini_set('display_errors', 0);

define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'bizflow');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('SITE_URL', (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\'));

require_once __DIR__ . '/activity.php';
require_once __DIR__ . '/notifications.php';

function timeAgo($ts) {
    $diff = time() - strtotime($ts);
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff / 60) . 'm ago';
    if ($diff < 86400) return floor($diff / 3600) . 'h ago';
    if ($diff < 2592000) return floor($diff / 86400) . 'd ago';
    return date('M d', strtotime($ts));
}

function generateAbbr($business_name) {
    $name = trim($business_name);
    if ($name === '') return 'BIZ';
    $first = explode(' ', $name)[0];
    $abbr = strtoupper(substr($first, 0, 3));
    return $abbr ?: 'BIZ';
}

function getAvatarInitials($name) {
    $parts = explode(' ', trim($name));
    $initials = '';
    foreach ($parts as $p) {
        if ($p !== '') $initials .= strtoupper($p[0]);
    }
    return substr($initials, 0, 2) ?: 'U';
}

function isPro() {
    return isset($_SESSION['is_pro']) && $_SESSION['is_pro'] === true;
}

function canAccessTemplates() {
    return isPro();
}

function getTemplates($pdo, $type = null) {
    if ($type) {
        $stmt = $pdo->prepare("SELECT * FROM templates WHERE is_active = 1 AND type = ? ORDER BY sort_order");
        $stmt->execute([$type]);
    } else {
        $stmt = $pdo->query("SELECT * FROM templates WHERE is_active = 1 ORDER BY sort_order");
    }
    return $stmt->fetchAll();
}

function getUserTemplate($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT t.* FROM templates t JOIN users u ON u.selected_template_id = t.id WHERE u.id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

function minify_html($buffer) {
    if ($buffer === '') return '';
    $buffer = preg_replace('/<!--(.|\s)*?-->/', '', $buffer);
    $buffer = str_replace(["\r\n", "\r", "\n", "\t"], ' ', $buffer);
    $buffer = preg_replace('/\s+/', ' ', $buffer);
    $buffer = preg_replace('/> </', '><', $buffer);
    return trim($buffer);
}
ob_start('minify_html');
register_shutdown_function(function() {
    while (ob_get_level()) ob_end_flush();
});

function csrf_token() {
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="_csrf_token" value="' . csrf_token() . '">';
}

function validate_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['_csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!hash_equals(csrf_token(), $token)) {
            http_response_code(403);
            die('Invalid CSRF token.');
        }
    }
}
