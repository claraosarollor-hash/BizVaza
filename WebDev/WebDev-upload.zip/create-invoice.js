document.addEventListener('DOMContentLoaded', () => {
    
    // === 1. NAVIGATION TAB SWITCHING ===
    const tabItems = document.querySelectorAll('.tab-item');
    const printableSheet = document.querySelector('.invoice-printable-sheet');
    const notesPane = document.querySelector('.details-pane-block'); // Targets the notes section

    tabItems.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Remove active class from all tabs
            tabItems.forEach(item => item.classList.remove('active'));
            // Add active class to clicked tab
            tab.classList.add('active');

            // Tab logic simulation
            if (tab.textContent.trim() === 'Notes') {
                // Smoothly highlight or scroll to notes block if previewing details
                notesPane.scrollIntoView({ behavior: 'smooth', block: 'center' });
                notesPane.style.outline = '2px solid #2563EB';
                notesPane.style.outlineOffset = '4px';
                notesPane.style.borderRadius = '8px';
                
                setTimeout(() => {
                    notesPane.style.outline = 'none';
                }, 2000);
            }
        });
    });

    // === 2. SPLIT BUTTON DROPDOWN CONTROL ===
    const arrowBtn = document.querySelector('.btn-primary-arrow');
    if (arrowBtn) {
        arrowBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            // Mocking a dropdown options layout menu action
            alert('Opening distribution options: Send via Email, Export Meta Data, or Schedule Delivery.');
        });
    }

    // === 3. DOWNLOAD MENU (PDF / Image) ===
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.download-wrap')) closeDownloadMenu();
    });

    // === 4. WHATSAPP SHARE WITH IMAGE ===
    // handled by global function shareViaWhatsApp(btn) defined below

    // === 5. SCALE-TO-FIT: fixed desktop layout, scaled down on small screens ===
    fitSheet();
});

function fitSheet() {
    const sheet = document.querySelector('.invoice-printable-sheet');
    if (!sheet) return;
    const wrap = sheet.parentElement;
    if (!wrap || !wrap.classList.contains('sheet-scroll')) return;
    const avail = wrap.clientWidth;
    if (avail <= 0) return;
    const scale = Math.min(1, avail / 720);
    if (scale < 1) {
        sheet.style.transform = 'scale(' + scale + ')';
        wrap.style.height = Math.round(sheet.offsetHeight * scale) + 'px';
    } else {
        sheet.style.transform = '';
        wrap.style.height = '';
    }
}

window.addEventListener('load', fitSheet);
window.addEventListener('resize', fitSheet);

function closeDownloadMenu() {
    const menu = document.querySelector('.download-menu');
    if (menu) menu.classList.remove('show');
}

function toggleDownloadMenu(e) {
    if (e) e.stopPropagation();
    const menu = document.querySelector('.download-menu');
    if (menu) menu.classList.toggle('show');
}

function downloadPdf(e) {
    if (e) e.preventDefault();
    closeDownloadMenu();
    window.print();
}

function downloadImage(e) {
    if (e) e.preventDefault();
    closeDownloadMenu();
    const sheet = document.querySelector('.invoice-printable-sheet');
    if (!sheet) return;
    const idText = document.querySelector('.invoice-id-number');
    const baseName = (idText ? idText.textContent.trim() : 'bizflow-document').replace(/[^a-zA-Z0-9-_]/g, '') || 'bizflow-document';

    function downloadPng(canvas) {
        canvas.toBlob(function(blob) {
            if (!blob) return;
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = baseName + '.png';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(function() { URL.revokeObjectURL(url); }, 4000);
        }, 'image/png');
    }

    if (typeof html2canvas !== 'undefined') {
        document.body.classList.add('js-capture');
        html2canvas(sheet, { scale: 2, useCORS: true }).then(function(canvas) {
            document.body.classList.remove('js-capture');
            downloadPng(canvas);
        }).catch(function() {
            document.body.classList.remove('js-capture');
        });
    }
}

function shareViaWhatsApp(btn) {
    const phone = btn.dataset.phone;
    const invoiceNum = document.querySelector('.invoice-id-number').textContent.trim();
    const clientName = document.querySelector('.client-name').textContent.trim();
    const totalAmount = document.querySelector('.val-total').textContent.trim();
    const sheet = document.querySelector('.invoice-printable-sheet');
    const message = 'Invoice ' + invoiceNum + ' for ' + clientName + ' — Total: ' + totalAmount;

    function fallback(phone, text) {
        var clean = phone ? phone.replace(/[^0-9]/g, '') : '';
        var url = clean ? 'https://wa.me/' + clean + '?text=' + encodeURIComponent(text) : 'https://wa.me/?text=' + encodeURIComponent(text);
        window.open(url, '_blank');
    }

    if (typeof html2canvas !== 'undefined' && sheet) {
        document.body.classList.add('js-capture');
        html2canvas(sheet, { scale: 2, useCORS: true }).then(function(canvas) {
            document.body.classList.remove('js-capture');
            canvas.toBlob(function(blob) {
                if (!blob) { fallback(phone, message); return; }
                var file = new File([blob], 'invoice-' + invoiceNum.replace(/[^a-zA-Z0-9-]/g, '') + '.png', { type: 'image/png' });
                if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
                    navigator.share({ files: [file], title: invoiceNum, text: message }).catch(function() {
                        fallback(phone, message);
                    });
                } else {
                    fallback(phone, message);
                }
            });
        }).catch(function() {
            document.body.classList.remove('js-capture');
            fallback(phone, message);
        });
    } else {
        fallback(phone, message);
    }
}